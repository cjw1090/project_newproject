구현기능
 - group/ungroup을 제외한 편집 메뉴
 - 도형의 회전