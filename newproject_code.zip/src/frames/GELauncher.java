package frames;

public class GELauncher {
	public static void main(String[] args) {
		GEMainFrame mainFrame = GEMainFrame.getInstance();
		mainFrame.init();
	}
}
